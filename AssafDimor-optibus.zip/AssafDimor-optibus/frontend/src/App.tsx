import { useState, useEffect } from "react";
import { getVehicles } from "../api/vehicles";
import type { Vehicle } from "../api/vehicles";
import VehicleTable from "./components/VehicleTable";
import FilterDropDown from "./components/FilterDropDown";
import { SquarePlus } from "lucide-react";
import NewVehicleForm from "./components/NewVehicleForm";

export default function App() {
  //app level constants
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [version, setVersion] = useState(0);
  const [filters, setFilters] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [formOpened, setFormOpened] = useState(false);
  //function on refresh changing the version state causing update of the vehicle list
  const onRefresh = () => {
    setVersion(version + 1);
  };

  //apply search and filter properties to the list
  const filteredVehicles = vehicles.filter((v) => {
    const matchesSearch = v.licensePlate
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesFilter = filters.length === 0 || filters.includes(v.status); //filters empty = present all
    return matchesSearch && matchesFilter;
  });

  //re fetching of vehicles list from server when version changes
  useEffect(() => {
    async function loadVehicles() {
      const v = await getVehicles();
      setVehicles(v);
    }
    loadVehicles();
  }, [version]);

  return (
    <div className="flex flex-col items-center w-full">
      <div className="flex flex-col align-middle items-center w-4/5">
        <p className="text-5xl mt-5 mb-10 text-blue-900 ">
          OptiBus Vehicle System
        </p>
        <div className="flex flex-row gap-5 ">
          {/*the actions div (add, search, filter) */}
          <button
            onClick={() => setFormOpened(true)}
            className="cursor-pointer align-top rounded-xl p-2 bg-blue-900"
          >
            <SquarePlus className="text-white" />
          </button>
          <input
            type="text"
            placeholder="Search by license plate"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border px-3 py-2 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
          />
          <FilterDropDown
            filters={filters}
            setFilters={setFilters}
            options={["Available", "InUse", "Maintenance"]}
          />
        </div>

        <VehicleTable vehicles={filteredVehicles} onRefresh={onRefresh} />
        <p className="text-xl mt-5 mb-10 text-gray-600 ">
          Created by Assaf Dimor for Optibus home assignment
        </p>
      </div>
      {/*the new vehicle form, has absolute location thus shows as pop up */}
      {formOpened && (
        <NewVehicleForm
          onAdded={() => {
            onRefresh();
            setFormOpened(false);
          }}
          onClose={() => setFormOpened(false)}
        />
      )}
    </div>
  );
}
