import { useState, type JSX } from "react";
import type { Vehicle } from "../../api/vehicles";

// creates a popover menu for changing status edit or deletion.
export default function ActionPopOver({
  vehicle,
  action,
  onConfirm,
}: {
  vehicle: Vehicle;
  action: "status" | "edit" | "delete";
  onConfirm: (value: any) => Promise<void> | void;
}) {
  const [newPlate, setNewPlate] = useState("");
  const [error, setError] = useState<string | null>(null);
  let content: JSX.Element | null = null;

  const handleClick = async (p?: any) => {
    try {
      setError(null);
      await Promise.resolve(onConfirm(p));
    } catch (err: unknown) {
      const message =
        err instanceof Error
          ? err.message
          : typeof err === "string"
          ? err
          : "Failed.";
      setError(message);
    }
  };

  //changes content in respect to the action selected
  switch (action) {
    case "status": {
      let options = ["Maintenance", "Available", "InUse"];
      if (vehicle.status === "Maintenance") {
        options = ["Available"];
      } else {
        options = options.filter((s) => s !== vehicle.status);
      }

      content = (
        // add buttons for new statuses
        <div className="flex flex-col gap-2">
          {options.map((o) => (
            <button
              key={o}
              className={`rounded-md text-white px-3 py-1 ${
                o === "Available"
                  ? "bg-green-600"
                  : o === "InUse"
                  ? "bg-yellow-500"
                  : o === "Maintenance"
                  ? "bg-red-600"
                  : ""
              }`}
              onClick={() => handleClick(o)}
            >
              {`Set as ${o}`}
            </button>
          ))}
        </div>
      );
      break;
    }

    // ask for input of new plate
    case "edit":
      content = (
        <div className="flex flex-col gap-2">
          <input
            type="text"
            placeholder="New plate number"
            value={newPlate}
            onChange={(e) => setNewPlate(e.target.value.toUpperCase())}
            className="border px-3 py-2 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
          />
          <button
            className="rounded-md bg-green-600 text-white px-3 py-1"
            onClick={() => handleClick(newPlate)}
          >
            Update
          </button>
        </div>
      );
      break;
    //ask to confirm deletion
    case "delete":
      content = (
        <div className="flex flex-col gap-2">
          <div className="text-lg font-semibold">Delete this vehicle?</div>
          <button
            className="rounded-md bg-red-600 text-white px-3 py-1"
            onClick={() => handleClick()}
          >
            Delete
          </button>
        </div>
      );
      break;

    default:
      content = null;
      break;
  }

  return (
    <div className="p-3 bg-white border shadow rounded-md w-64">
      {content}
      {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
    </div>
  );
}
