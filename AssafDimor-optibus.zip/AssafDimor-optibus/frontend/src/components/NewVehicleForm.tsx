import { useState } from "react";
import { createVehicle } from "../../api/vehicles"; // create this in your api file if not yet there
import { validatePlate } from "../utils/LicensePlate";
export default function NewVehicleForm({
  onClose,
  onAdded,
}: {
  onClose: () => void;
  onAdded: () => void;
}) {
  const [licensePlate, setLicensePlate] = useState("");

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const plateValidation = validatePlate(licensePlate);
    if (!plateValidation.isValid) {
      setError(plateValidation.error || "plate invalid");
      return;
    }
    try {
      setError(null);
      setLoading(true);
      await createVehicle(licensePlate);
      setLicensePlate("");
      onAdded(); // refresh table
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "failed to add vehicle";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md relative">
        {/* close button */}
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
        >
          ✕
        </button>

        <h2 className="text-lg font-semibold text-gray-700 mb-3">
          add new vehicle
        </h2>

        {/* your same inputs */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <input
            type="text"
            placeholder="license plate"
            value={licensePlate}
            onChange={(e) => {
              setLicensePlate(e.target.value.toUpperCase());
            }}
            className="border px-3 py-2 rounded-md focus:outline-none focus:ring focus:ring-blue-200"
          />

          {error && <p className="text-red-600 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="bg-blue-600 text-white rounded-md py-2 hover:bg-blue-700 disabled:opacity-60"
          >
            {loading ? "adding..." : "vehicle added"}
          </button>
        </form>
      </div>
    </div>
  );
}
