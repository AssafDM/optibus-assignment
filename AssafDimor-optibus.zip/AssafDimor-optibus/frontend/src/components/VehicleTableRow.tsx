import React, { useEffect, useRef, useState } from "react";
import {
  changePlate,
  changeStatus,
  deleteById,
  type Vehicle,
} from "../../api/vehicles";
import { formatPlate } from "../utils/LicensePlate";
import ActionPopOver from "./ActionPopOver";

//defines a table row of a vehicle, expands onclick to show action buttons
export default function VehicleTableRow({
  v,
  expanded,
  setExpanded,
  onRefresh,
}: {
  v: Vehicle;
  expanded: string | null;
  setExpanded: (s: string | null) => void;
  onRefresh: () => void;
}) {
  // the action popup (edit/delete/status) - contains coordinates for popup
  const [activeAction, setActiveAction] = useState<{
    vehicle: Vehicle;
    action: "status" | "edit" | "delete";
    x: number;
    y: number;
  } | null>(null);
  // ref for outside click
  const popoverRef = useRef<HTMLDivElement | null>(null);

  //lose popup if click outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(e.target as Node)
      ) {
        setActiveAction(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <React.Fragment key={v.id}>
      {/* normal row */}
      <tr
        className="odd:bg-white even:bg-blue-50 hover:bg-blue-200 transition cursor-pointer"
        onClick={() => setExpanded(expanded === v.id ? null : v.id)}
      >
        <td className="px-4 py-2 border-t">{v.id}</td>
        <td className="px-4 py-2 border-t">{formatPlate(v.licensePlate)}</td>
        <td className="px-4 py-2 border-t">{v.status}</td>
        <td className="px-4 py-2 border-t">{v.createdAt.toLocaleString()}</td>
      </tr>

      {v.id === expanded && (
        <>
          <tr className="even:bg-white odd:bg-blue-50">
            <td colSpan={4} className="px-4 py-3 border-b">
              <div className="flex justify-around gap-4">
                <button
                  className="w-full rounded-md bg-blue-600 text-white py-2"
                  onClick={(e) =>
                    setActiveAction({
                      vehicle: v,
                      action: "status",
                      x: e.clientX,
                      y: e.clientY,
                    })
                  }
                >
                  Change Status
                </button>

                <button
                  className="w-full rounded-md bg-green-600 text-white py-2"
                  onClick={(e) =>
                    setActiveAction({
                      vehicle: v,
                      action: "edit",
                      x: e.clientX,
                      y: e.clientY,
                    })
                  }
                >
                  Edit
                </button>

                <button
                  className="w-full rounded-md bg-red-600 text-white py-2"
                  onClick={(e) =>
                    setActiveAction({
                      vehicle: v,
                      action: "delete",
                      x: e.clientX,
                      y: e.clientY,
                    })
                  }
                >
                  Delete
                </button>
              </div>
            </td>
          </tr>
          <tr>
            {/*empty row to keep colors consistent and facilitate the popover*/}
            {/* popup thing for edit/status/delete */}
            {activeAction && activeAction.vehicle.id === expanded && (
              <div
                ref={popoverRef}
                className="fixed z-50"
                style={{ top: activeAction.y, left: activeAction.x }}
              >
                <ActionPopOver
                  vehicle={activeAction.vehicle}
                  action={activeAction.action}
                  onConfirm={async (value: any) => {
                    try {
                      // call api according to the action type
                      if (activeAction.action === "status") {
                        await changeStatus(activeAction.vehicle.id, value);
                      } else if (activeAction.action === "edit") {
                        await changePlate(activeAction.vehicle.id, value);
                      } else if (activeAction.action === "delete") {
                        await deleteById(activeAction.vehicle.id);
                      }

                      // refresh data from parent
                      onRefresh();

                      // close popup
                      setActiveAction(null);
                    } catch (err) {
                      // the popup handles showing err text
                      throw err;
                    }
                  }}
                />
              </div>
            )}
          </tr>
        </>
      )}
    </React.Fragment>
  );
}
