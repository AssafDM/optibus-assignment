import { Menu, MenuButton, MenuItems } from "@headlessui/react";

export default function FilterDropDown({
  filters,
  setFilters,
  options,
}: {
  filters: string[];
  setFilters: (value: string[] | ((prev: string[]) => string[])) => void;
  options: string[];
}) {
  //update filters upon click
  const toggleFilter = (status: string) => {
    setFilters((prev) =>
      prev.includes(status)
        ? prev.filter((f) => f !== status)
        : [...prev, status]
    );
  };

  return (
    <Menu as="div" className="relative inline-block text-left">
      <MenuButton className="border px-3 py-2 rounded-md bg-white shadow-sm hover:bg-gray-100">
        {filters.length > 0
          ? `Filters (${filters.length}) `
          : "Filter Status ▾"}
      </MenuButton>

      <MenuItems className="absolute mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-20">
        {options.map((status) => (
          <div
            key={status}
            onClick={(e) => e.stopPropagation()} // keeps dropdown open
            className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={filters.includes(status)}
              onChange={() => toggleFilter(status)}
              className="mr-2"
            />
            <label>{status}</label>
          </div>
        ))}

        <div className="border-t">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setFilters([]);
            }}
            className="w-full text-sm text-gray-500 py-2 hover:bg-gray-50"
          >
            Clear All
          </button>
        </div>
      </MenuItems>
    </Menu>
  );
}
