import { useMemo, useState } from "react";
import type { Vehicle } from "../../api/vehicles";
import VehicleTableRow from "./VehicleTableRow";

type VehicleAttribute = "licensePlate" | "status" | "createdAt";

interface VehicleTableProps {
  vehicles: Vehicle[];
  onRefresh: () => void;
}

//shows a tables of vehicles with action buttons
export default function VehicleTable({
  vehicles,
  onRefresh,
}: VehicleTableProps) {
  const [sortBy, setSortBy] = useState<VehicleAttribute>("createdAt");

  const [sortDirection, setSortDirection] = useState(1);

  // expanded row state - equals to the id or the open row or null for close
  const [expanded, setExpanded] = useState<string | null>(null);

  //sort vehicles by selected column
  const sortedVehicles = useMemo(() => {
    return [...vehicles].sort((a, b) => {
      if (sortBy === "createdAt") {
        return (
          (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) *
          sortDirection
        );
      }
      const valA = a[sortBy].toString().toLowerCase();
      const valB = b[sortBy].toString().toLowerCase();
      return valA.localeCompare(valB) * sortDirection;
    });
  }, [vehicles, sortBy, sortDirection]);

  // handle when user click on header to sort
  const handleSortClick = (field: VehicleAttribute) => {
    if (sortBy !== field) {
      setSortBy(field);
      setSortDirection(1);
    } else {
      setSortDirection((d) => -d); //second click changes direction (acsending/decsending)
    }
  };

  // direction marker
  const directionSymbol = sortDirection === -1 ? "▲" : "▼";

  return (
    // table layout
    <div className="w-full p-6">
      <table className="w-full border border-gray-300 rounded-lg overflow-hidden">
        <thead className="bg-blue-50 text-left select-none">
          <tr>
            <th className="px-4 py-2 border-b">V.ID</th>
            {/*vid does no support sorting fot it is randomized */}
            <th
              className="px-4 py-2 border-b cursor-pointer"
              onClick={() => handleSortClick("licensePlate")}
            >
              License Plate {sortBy === "licensePlate" && directionSymbol}
            </th>
            <th
              className="px-4 py-2 border-b cursor-pointer"
              onClick={() => handleSortClick("status")}
            >
              Status {sortBy === "status" && directionSymbol}
            </th>
            <th
              className="px-4 py-2 border-b cursor-pointer"
              onClick={() => handleSortClick("createdAt")}
            >
              Created At {sortBy === "createdAt" && directionSymbol}
            </th>
          </tr>
        </thead>

        <tbody>
          {sortedVehicles.map((v) => (
            <VehicleTableRow
              key={v.id}
              v={v}
              expanded={expanded} //global to allow 1 expanded row
              setExpanded={setExpanded}
              onRefresh={onRefresh}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}
