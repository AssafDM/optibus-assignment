export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

// util function to format modern israely plate numbers (7/8 digits), does not format any other form
export function formatPlate(plate: string) {
  if (/^\d+$/.test(plate)) {
    //plate is numeric
    if (plate.length == 7)
      return `${plate.slice(0, 2)}-${plate.slice(2, 5)}-${plate.slice(5, 7)}`;
    if (plate.length == 8)
      return `${plate.slice(0, 3)}-${plate.slice(3, 5)}-${plate.slice(5, 8)}`;
    else return plate;
  } else return plate;
}

// Validate license plate format (matches backend validation)
export function validatePlate(plate: string): ValidationResult {
  if (!plate || typeof plate !== "string") {
    return { isValid: false, error: "License plate is required" };
  }

  // Only allow letters and numbers (alphanumeric)
  const alphanumericRegex = /^[A-Za-z0-9]+$/;
  if (!alphanumericRegex.test(plate)) {
    return {
      isValid: false,
      error: "License plate can only contain letters and numbers",
    };
  }

  return { isValid: true };
}
