const API_BASE = "http://localhost:3000/api"; // change port here if necessairy

export type VehicleStatus = "Maintenance" | "InUse" | "Available";

export interface Vehicle {
  id: string;
  licensePlate: string;
  status: VehicleStatus;
  createdAt: string | Date; // can be either raw string or converted Date
}

// Helper: convert Date object
function normalizeVehicle(v: Vehicle): Vehicle {
  return {
    ...v,
    createdAt: new Date(v.createdAt),
  };
}
// Helper: update vehicle
async function updateVehicle(
  id: string,
  data: Partial<Vehicle>
): Promise<Vehicle> {
  const res = await fetch(`${API_BASE}/vehicles/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(await res.text());
  return normalizeVehicle(await res.json());
}

// get all vehicles
export async function getVehicles(): Promise<Vehicle[]> {
  const res = await fetch(`${API_BASE}/vehicles`);
  if (!res.ok) throw new Error("Failed to fetch vehicles");
  const data = await res.json();
  return data.map(normalizeVehicle);
}

// create new vehicle with number plate
export async function createVehicle(licensePlate: string): Promise<Vehicle> {
  const res = await fetch(`${API_BASE}/vehicles`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ licensePlate }),
  });
  if (!res.ok) throw new Error(await res.text());
  return normalizeVehicle(await res.json());
}

// delete vehicle by id
export async function deleteById(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/vehicles/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error(await res.text());
}

//change vehicle status
export async function changeStatus(id: string, status: VehicleStatus) {
  return updateVehicle(id, { status });
}
//edit vehicle plate
export async function changePlate(id: string, licensePlate: string) {
  return updateVehicle(id, { licensePlate });
}
