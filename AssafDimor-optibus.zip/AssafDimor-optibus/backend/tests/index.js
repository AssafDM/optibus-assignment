const BASE_URL = process.env.BASE_URL || "http://localhost:3000";

async function request(method, path, body) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch (_) {}
  return { status: res.status, data };
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function run() {
  const results = [];
  try {
    // 1) Create valid vehicle
    const plate = `TEST${Math.floor(Math.random() * 1e6)}`;
    const create = await request("POST", "/api/vehicles", {
      licensePlate: plate,
    });
    assert(create.status === 201, `Create expected 201, got ${create.status}`);
    assert(
      create.data?.licensePlate === plate.toUpperCase(),
      "Plate should be normalized to uppercase"
    );
    results.push("POST valid: OK");
    const id = create.data.id;

    // 2) Reject invalid plate
    const createBad = await request("POST", "/api/vehicles", {
      licensePlate: "A-123",
    });
    assert(
      createBad.status === 400,
      `Invalid plate expected 400, got ${createBad.status}`
    );
    results.push("POST invalid plate: OK");

    // 3) Duplicate plate
    const dup = await request("POST", "/api/vehicles", {
      licensePlate: plate.toLowerCase(),
    });
    assert(dup.status === 400, `Duplicate expected 400, got ${dup.status}`);
    results.push("POST duplicate: OK");

    // 4) Reject invalid status
    const badStatus = await request("PUT", `/api/vehicles/${id}`, {
      status: "Flying",
    });
    assert(
      badStatus.status === 400,
      `Invalid status expected 400, got ${badStatus.status}`
    );
    results.push("PUT invalid status: OK");

    // 5) InUse -> Maintenance rule (cap-aware)
    const toInUse = await request("PUT", `/api/vehicles/${id}`, {
      status: "InUse",
    });
    assert(toInUse.status === 200, `InUse expected 200, got ${toInUse.status}`);

    const toMaint = await request("PUT", `/api/vehicles/${id}`, {
      status: "Maintenance",
    });
    if (toMaint.status === 200) {
      const toInUseBad = await request("PUT", `/api/vehicles/${id}`, {
        status: "InUse",
      });
      assert(
        toInUseBad.status === 400,
        `Maintenance->InUse expected 400, got ${toInUseBad.status}`
      );
      results.push("Maintenance->InUse blocked: OK");

      const toAvail = await request("PUT", `/api/vehicles/${id}`, {
        status: "Available",
      });
      assert(
        toAvail.status === 200,
        `Maintenance->Available expected 200, got ${toAvail.status}`
      );
      results.push("Maintenance->Available: OK");
    } else if (toMaint.status === 400) {
      results.push("Maintenance skipped (cap reached): OK");
    } else {
      throw new Error(
        `Unexpected Maintenance transition code ${toMaint.status}`
      );
    }

    // 6) Delete only Available
    const toUse = await request("PUT", `/api/vehicles/${id}`, {
      status: "InUse",
    });
    assert(
      toUse.status === 200,
      `Status InUse expected 200, got ${toUse.status}`
    );
    const badDel = await request("DELETE", `/api/vehicles/${id}`);
    assert(
      badDel.status === 400,
      `Delete non-Available expected 400, got ${badDel.status}`
    );
    results.push("DELETE non-Available: OK");

    const toAvail2 = await request("PUT", `/api/vehicles/${id}`, {
      status: "Available",
    });
    assert(
      toAvail2.status === 200,
      `Status Available expected 200, got ${toAvail2.status}`
    );
    const del = await request("DELETE", `/api/vehicles/${id}`);
    assert(del.status === 204, `Delete expected 204, got ${del.status}`);
    results.push("DELETE Available blocked: OK");

    // 7) Delete non-existent vehicle
    const delUnknown = await request("DELETE", "/api/vehicles/UNKNOWN123");
    assert(
      delUnknown.status === 404,
      `Delete unknown expected 404, got ${delUnknown.status}`
    );
    results.push("DELETE unknown: OK");

    // 8) Maintenance cap test (account for existing vehicles)
    const before = await request("GET", "/api/vehicles");
    const startCount = before.data.length;

    const createdIds = [];
    for (let i = 0; i < 50; i++) {
      const randPlate = `CAP${Math.floor(Math.random() * 1e6)}`;
      const v = await request("POST", "/api/vehicles", {
        licensePlate: randPlate,
      });
      if (v.status === 201) createdIds.push(v.data.id);
    }

    // current total vehicle count in DB after adding new ones
    const totalNow = startCount + createdIds.length;
    const limit = Math.floor(totalNow * 0.05) || 1;

    // move enough to reach cap
    for (let i = 0; i < limit; i++) {
      await request("PUT", `/api/vehicles/${createdIds[i]}`, {
        status: "Maintenance",
      });
    }

    // try to exceed it
    const over = await request("PUT", `/api/vehicles/${createdIds[limit]}`, {
      status: "Maintenance",
    });
    if (over.status === 400) {
      results.push("Maintenance cap limit: OK");
    } else if (over.status === 200) {
      results.push("Maintenance cap not triggered (cap not reached in DB): OK");
    } else {
      throw new Error(
        `Unexpected response for maintenance cap: ${over.status}`
      );
    }

    console.log("All tests passed:\n- " + results.join("\n- "));
    process.exit(0);
  } catch (err) {
    console.error("Test failed:", err.message);
    process.exit(1);
  }
}

run();
