import express from "express";
import cors from "cors";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

//server port is defaulted to 3000 can change as env variable PORT
const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataPath = path.join(__dirname, "../vehicles.json");
const MAINTENANCE_CAP = 0.05; //maintenance max capacity

interface Vehicle {
  id: string;
  licensePlate: string;
  status: "Available" | "InUse" | "Maintenance";
  createdAt: string;
}
//random id generator, small size for this example
function generateId(length = 6) {
  // 8 bytes = 64 bits randomness
  const num = BigInt("0x" + crypto.randomBytes(8).toString("hex"));
  return num.toString(36).toUpperCase().slice(0, length);
}

// License plate validation - only letters and numbers
function validateLicensePlate(plate: string): {
  isValid: boolean;
  error?: string;
} {
  if (!plate || typeof plate !== "string") {
    return { isValid: false, error: "License plate is required" };
  }

  // Only allow letters and numbers (alphanumeric)
  const alphanumericRegex = /^[A-Za-z0-9]+$/;
  if (!alphanumericRegex.test(plate)) {
    return {
      isValid: false,
      error: "License plate can only contain letters and numbers",
    };
  }

  return { isValid: true };
}
/*server loads from storage then works on memory with backing up on file  */
let vehicles: Vehicle[] = [];

/* === Load seed data on startup / latest data (persintance)=== */
async function loadVehicles() {
  try {
    const file = await fs.readFile(dataPath, "utf-8");
    vehicles = JSON.parse(file);
    console.log(`Loaded ${vehicles.length} vehicles from vehicles.json`);
  } catch (err) {
    console.warn("Could not load vehicles.json, starting empty.");
    vehicles = [];
  }
}

/* === Save changes to disk === */
async function saveVehicles() {
  await fs.writeFile(dataPath, JSON.stringify(vehicles, null, 2));
}

/* === Express setup === */
const app = express();
app.use(cors());
app.use(express.json());

/* === Routes === */

// Get all vehicles
app.get("/api/vehicles", (_, res) => {
  res.json(vehicles);
});

// Create vehicle
app.post("/api/vehicles", async (req, res) => {
  const { licensePlate } = req.body;

  // Validate license plate
  const validation = validateLicensePlate(licensePlate);
  if (!validation.isValid) {
    return res.status(400).json({ error: validation.error });
  }

  // Check for duplicate license plate
  const existingVehicle = vehicles.find(
    (v) => v.licensePlate.toUpperCase() === licensePlate.toUpperCase()
  );
  if (existingVehicle) {
    return res.status(400).json({ error: "License plate already exists" });
  }

  const newVehicle: Vehicle = {
    id: generateId(),
    licensePlate: licensePlate.toUpperCase(),
    status: "Available", //new Vehicle always available
    createdAt: new Date().toISOString(),
  };
  vehicles.push(newVehicle);
  await saveVehicles();
  res.status(201).json(newVehicle);
});

// Update vehicle (status or plate)
app.put("/api/vehicles/:id", async (req, res) => {
  const { licensePlate, status } = req.body;
  const id = req.params.id;

  const vehicle = vehicles.find((v) => v.id === id);
  if (!vehicle) return res.status(404).send("Vehicle not found");

  // === VALIDATION RULES ===

  // Validate status value if provided
  if (status) {
    const validStatuses = ["Available", "InUse", "Maintenance"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: `Invalid status. Must be one of: ${validStatuses.join(", ")}`,
      });
    }
  }

  // If status is changing, validate legality to rules
  if (status && status !== vehicle.status) {
    // follow maintenance to available rule
    if (vehicle.status === "Maintenance" && status !== "Available") {
      return res
        .status(400)
        .send("A vehicle in Maintenance can only move to Available");
    }
    //follow mainenance cap restriction
    const maintenanceCount = vehicles.filter(
      (v) => v.status === "Maintenance"
    ).length;
    const limit = Math.floor(vehicles.length * MAINTENANCE_CAP);
    if (status === "Maintenance" && maintenanceCount >= limit) {
      return res
        .status(400)
        .send(
          `Cannot put more than ${
            MAINTENANCE_CAP * 100
          }% of vehicles in Maintenance`
        );
    }

    // Everything passed
    vehicle.status = status;
  }

  // Update license plate if provided
  if (licensePlate) {
    // Validate license plate
    const validation = validateLicensePlate(licensePlate);
    if (!validation.isValid) {
      return res.status(400).json({ error: validation.error });
    }

    // Check for duplicate license plate (excluding current vehicle)
    const existingVehicle = vehicles.find(
      (v) =>
        v.id !== id &&
        v.licensePlate.toUpperCase() === licensePlate.toUpperCase()
    );
    if (existingVehicle) {
      return res.status(400).json({ error: "License plate already exists" });
    }

    vehicle.licensePlate = licensePlate.toUpperCase();
  }
  // save
  await saveVehicles();
  res.json(vehicle);
});

// Delete vehicle
app.delete("/api/vehicles/:id", async (req, res) => {
  const idx = vehicles.findIndex((v) => v.id === req.params.id);
  if (idx === -1) return res.status(404).send("Not found");
  const status = vehicles[idx]?.status;
  if (status !== "Available")
    return res
      .status(400)
      .send(`Error in deletion: Vehicle status is ${status}`);

  vehicles.splice(idx, 1);
  await saveVehicles();
  res.status(204).send();
});

app.get("/", (_, res) => res.send("running"));

/* === Start server === */

app.listen(PORT, async () => {
  await loadVehicles();
  console.log(`Server on http://localhost:${PORT}`);
});
